from django.test import TestCase

class LendMoneyTests(TestCase):
    def test_example(self):
        self.assertEqual(1 + 1, 2)  # Example test case to ensure the test framework is working.